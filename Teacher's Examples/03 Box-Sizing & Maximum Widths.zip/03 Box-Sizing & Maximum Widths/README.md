# 03 – Box-Sizing & Maximum Widths

---

## References

The reset code that we will be using this term is an updated and slightly modified version of A Modern Reset by Andy Bell. 

Source: https://piccalil.li/blog/a-more-modern-css-reset/


The text is courtesy of Project Gutenberg, an online repository of literary works in the public domain.

Source: https://www.gutenberg.org/cache/epub/2701/pg2701-images.html